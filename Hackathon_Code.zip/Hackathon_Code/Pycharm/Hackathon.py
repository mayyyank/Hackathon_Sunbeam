from flask import Flask, request, render_template
import pickle
import numpy as np

# Load the model
with open('model.pkl', 'rb') as file:
    model = pickle.load(file)

app = Flask(__name__)


@app.route('/', methods=["GET"])
def root():
    return render_template('index.html')


@app.route('/predict', methods=["POST"])
def predict():
    try:
        # Retrieve form data and handle missing fields
        DisbursalAmount = float(request.form.get('DisbursalAmount', 0))
        AssetCost = int(request.form.get('AssetCost', 0))
        No_of_transaction = int(request.form.get('No_of_transaction', 0))
        LoanStatus_Active = int(request.form.get('LoanStatus_Active', 0))
        Account_status_active = int(request.form.get('ACCOUNT-STATUS_Active', 0))
        Account_status_closed = int(request.form.get('ACCOUNT-STATUS_Closed', 0))
        Disbursal_cost = float(request.form.get('Disbursal_cost', 0))
        loan_tenure = float(request.form.get('loan_tenure', 0))
        LIV = float(request.form.get('LIV', 0))

        # Prediction
        input_features = np.array([
            DisbursalAmount, AssetCost, No_of_transaction,
            LoanStatus_Active, Account_status_active,
            Account_status_closed, Disbursal_cost,
            loan_tenure, LIV
        ]).reshape(1, -1)

        predictions = model.predict(input_features)
        result = 'Customer will opt for top-up loan' if predictions[0] == 1 else 'Customer will not opt for top-up loan'

        return render_template('predicted.html', prediction=result)

    except ValueError as e:
        return f"Error in processing input: {e}"


app.run('0.0.0.0', 5400, debug=True)
